const { Router } = require('express');
const {
  createTweet,
  getTweet,
  getRandomTweets,
  getUserTweets,
  searchTweets,
  likeTweet,
  reTweet,
  getAllTweets,
  unlikeTweet,
  bookmarkTweet,
  removeBookmark,
  getBookmarks,
} = require('../services/postController');
const postRouter = Router();

postRouter.post('/', createTweet);

postRouter.get('/tweet/:id', getTweet);

postRouter.post('/tweet/:id/like', likeTweet);

postRouter.post('/tweet/:id/unlike', unlikeTweet);

postRouter.post('/tweet/:id/bookmark', bookmarkTweet);

postRouter.post('/tweet/:id/unbookmark', removeBookmark);

postRouter.post('/tweet/:id/retweet', reTweet);

postRouter.get('/all', getAllTweets);

postRouter.get('/random', getRandomTweets);

postRouter.get('/search', searchTweets);

postRouter.get('/bookmarks/:userId', getBookmarks);

postRouter.get('/user/:userId', getUserTweets);

module.exports = postRouter;
