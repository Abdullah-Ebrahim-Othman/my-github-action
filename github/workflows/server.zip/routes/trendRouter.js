const { Router } = require('express');
const {
  getTopTrends,
  getTweetsByHashtag,
} = require('../services/trendController');
const trendRouter = Router();

// Get top 5 trends
trendRouter.get('/', getTopTrends);

// Get tweets by hashtag
trendRouter.get('/:hashtag', getTweetsByHashtag);

module.exports = trendRouter;
