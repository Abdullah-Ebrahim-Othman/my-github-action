export {};

declare global {
  namespace NodeJS {
    interface ProcessEnv {
      EXPRESS_PORT: number;
      DATABASE_HOST: string;
      NODE_ENV: 'test' | 'development' | 'production';
      CLOUDINARY_CLOUD_NAME: string;
      CLOUDINARY_API_KEY: string;
      CLOUDINARY_API_SECRET: string;
    }
  }
}
