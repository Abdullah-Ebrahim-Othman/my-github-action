module.exports.extractHashtags = (text) => {
  const regex = /#(\w+)/g;
  let matches = [];
  let match;
  while ((match = regex.exec(text)) !== null) {
    matches.push(match[1].toLowerCase());
  }
  return matches;
};
