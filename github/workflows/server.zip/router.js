const userRouter = require('./routes/userRouter');
const trendRouter = require('./routes/trendRouter');
const postRouter = require('./routes/postRouter');
module.exports.loadRoutes = async function loadRoutes(app) {
  await app.use('/api/users', userRouter);
  await app.use('/api/trends', trendRouter);
  await app.use('/api/tweets', postRouter);
};
