const { Schema, model } = require('mongoose');
const tweetSchema = new Schema({
  content: {
    type: String,
    required: false,
    maxlength: 280,
  },
  author: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  image: String,
  likes: [{ type: Schema.Types.ObjectId, ref: 'User' }],
  bookmarks: [{ type: Schema.Types.ObjectId, ref: 'User' }],
  retweets: [{ type: Schema.Types.ObjectId, ref: 'User' }],
  retweetOf: { type: Schema.Types.ObjectId, ref: 'Tweet' },
  comments: [{ type: Schema.Types.ObjectId, ref: 'Comment' }],
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = {
  tweetModel: model('Tweet', tweetSchema),
};
