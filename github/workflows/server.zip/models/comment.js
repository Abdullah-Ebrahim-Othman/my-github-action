const { Schema, model } = require('mongoose');
const commentSchema = new Schema({
  content: {
    type: String,
    required: true,
    maxlength: 280,
  },
  author: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  tweet: {
    type: Schema.Types.ObjectId,
    ref: 'Tweet',
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = {
  commentModel: model('Comment', commentSchema),
};
