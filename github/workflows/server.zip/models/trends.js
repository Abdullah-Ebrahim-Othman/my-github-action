const { Schema, model } = require('mongoose');
const trendsModel = new Schema({
  hashtag: {
    type: String,
    required: true,
    unique: true,
  },
  count: {
    type: Number,
    default: 1,
  },
});

module.exports = {
  trendsModel: model('Trend', trendsModel),
};
