const { tweetModel: Tweet } = require('../models/tweet');
const { trendsModel: Trend } = require('../models/trends');
const { userModel: User } = require('../models/user');
const { extractHashtags } = require('../util/generalUtil');
const cloudinary = require('cloudinary').v2;
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// createTweet: POST {content: '', userId: ''}
const createTweet = async (req, res) => {
  let { content, userId, image = '' } = req.body;
  if (image) {
    const imageUrl = await cloudinary.uploader.upload(image, {
      //optional things just if you want some storage optimization
      overwrite: true,
      invalidate: true,
      width: 1080,
      height: 1080,
      crop: 'fill',
    });
    image = imageUrl.url ? imageUrl.url : '';
  }
  try {
    const tweet = new Tweet({
      content,
      image,
      author: userId,
    });
    await tweet.save();

    // Extract hashtags and update trends
    const hashtags = extractHashtags(content);
    for (const hashtag of hashtags) {
      let trend = await Trend.findOne({ hashtag });
      if (trend) {
        trend.count += 1;
        await trend.save();
      } else {
        await new Trend({ hashtag }).save();
      }
    }

    const tweetResponse = await tweet.populate('author', 'username profile');

    res.status(201).json(tweetResponse);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// getTweet: GET /:id
const getTweet = async (req, res) => {
  try {
    const tweet = await Tweet.findById(req.params.id)
      .populate('author', 'username profile')
      .populate('retweetOf', 'content author')
      .populate({
        path: 'retweetOf',
        populate: { path: 'author', select: 'username profile' },
      });
    /*
      .populate({
        path: 'comments',
        populate: { path: 'author', select: 'username' },
      })
      .populate('retweetOf', 'content author');
      */
    console.log(tweet, req.params.id);
    if (!tweet) {
      return res.status(404).json({ error: 'Tweet not found' });
    }

    res.json(tweet);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// getRandomTweets: GET
const getRandomTweets = async (req, res) => {
  try {
    const count = await Tweet.countDocuments();
    const randomIndex = Math.floor(Math.random() * count);
    const tweets = await Tweet.find({})
      .skip(randomIndex)
      .limit(5)
      .populate('author', 'username profile');
    res.json(tweets);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

const getAllTweets = async (req, res) => {
  try {
    const tweets = await Tweet.find().populate('author', 'username profile');
    res.json(tweets);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// getUserTweets : GET /:userId
const getUserTweets = async (req, res) => {
  const { userId } = req.params;

  try {
    const tweets = await Tweet.find({ author: userId })
      .populate('author', 'username profile')
      .populate('retweetOf', 'content author');

    res.json(tweets);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// likeTweet: POST {likerId: string;}
const likeTweet = async (req, res) => {
  try {
    const tweet = await Tweet.findById(req.params.id);

    if (!tweet) {
      return res.status(404).json({ error: 'Tweet not found' });
    }
    if (!tweet.likes.includes(req.body.likerId)) {
      tweet.likes.push(req.body.likerId);
      await tweet.save();
    }

    res.json(tweet);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// unlikeTweet: POST {userId: string}
const unlikeTweet = async (req, res) => {
  try {
    const tweet = await Tweet.findById(req.params.id);

    if (!tweet) {
      return res.status(404).json({ error: 'Tweet not found' });
    }

    if (!tweet.likes.includes(req.body.userId))
      return res.status(422).json({ error: 'User did not like the tweet' });
    const userLikeIdx = tweet.likes.indexOf(req.body.userId);
    if (userLikeIdx !== -1) {
      tweet.likes.splice(userLikeIdx, 1);
    }

    await tweet.save();

    res.json(tweet);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// reTweet: POST {retweeterId: string;}
// TODO: Support for custom retweet content for retweeter.
const reTweet = async (req, res) => {
  try {
    const originalTweet = await Tweet.findById(req.params.id);

    if (!originalTweet) {
      return res.status(404).json({ error: 'Tweet not found' });
    }

    const retweet = new Tweet({
      content: '',
      author: req.body.retweeterId,
      retweetOf: originalTweet._id,
    });

    await retweet.save();

    originalTweet.retweets.push(req.body.retweeterId);
    await originalTweet.save();

    res.status(201).json(retweet);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// searchTweet : GET /?q=keyword
const searchTweets = async (req, res) => {
  try {
    const searchTerm = req.query.q;
    if (!searchTerm) {
      return res.status(400).json({ error: 'Search term is required' });
    }

    const tweets = await Tweet.find({
      content: { $regex: searchTerm, $options: 'i' },
    }).populate('author', 'username profile');
    /*
      .populate({
        path: 'comments',
        populate: { path: 'author', select: 'username' },
      })
      .populate('retweetOf', 'content author');
      */

    res.json(tweets);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

const bookmarkTweet = async (req, res) => {
  try {
    const { id: tweetId } = req.params;
    const { userId } = req.body;
    console.log(userId, userId);
    const tweet = await Tweet.findByIdAndUpdate(
      tweetId,
      { $addToSet: { bookmarks: userId } },
      { new: true }
    ).populate('author', 'username profile');
    console.log(tweet);
    const user = await User.findByIdAndUpdate(
      userId,
      { $addToSet: { bookmarks: tweetId } },
      { new: true }
    );

    if (!tweet || !user) {
      return res.status(404).json({ error: 'Tweet or User not found' });
    }

    res.json(tweet);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Remove bookmark from a tweet
const removeBookmark = async (req, res) => {
  try {
    const { id: tweetId } = req.params;
    const { userId } = req.body;

    const tweet = await Tweet.findByIdAndUpdate(
      tweetId,
      { $pull: { bookmarks: userId } },
      { new: true }
    ).populate('author', 'username profile');

    const user = await User.findByIdAndUpdate(
      userId,
      { $pull: { bookmarks: tweetId } },
      { new: true }
    );
    console.log(tweet, user);
    if (!tweet || !user) {
      return res.status(404).json({ error: 'Tweet or User not found' });
    }

    res.json(tweet);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Get all bookmarks for a user
const getBookmarks = async (req, res) => {
  try {
    const { userId } = req.params;

    const user = await User.findById(userId).populate({
      path: 'bookmarks',
      select: 'author content likes retweets retweetOf image bookmarks',
      populate: [
        {
          path: 'author',
          select: 'username profile',
        },
        {
          path: 'retweetOf',
          select: 'content author',
        },
      ],
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json(user.bookmarks);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};
module.exports = {
  getTweet,
  createTweet,
  getRandomTweets,
  getUserTweets,
  searchTweets,
  likeTweet,
  reTweet,
  getAllTweets,
  unlikeTweet,
  bookmarkTweet,
  removeBookmark,
  getBookmarks,
};
