const { userModel: User } = require('../models/user');

// Register a new user
// registerUser: POST {username: '', email: '', password: '', profile?: {name: '', bio: '', location: '', website: '', avatar: '', banner: '' }}
const registerUser = async (req, res) => {
  let { username, email, password, profile } = req.body;
  if (!profile) {
    profile = {
      name: username,
      bio: '',
      location: '',
      website: '',
      avatar: 'https://avatar.oxro.io/avatar.png?name=' + username,
      banner: 'https://picsum.photos/1500/500',
    };
  }
  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res
        .status(400)
        .json({ error: 'Email is already used by another account.' });
    }

    const user = new User({ username, email, password, profile });
    await user.save();
    res.status(201).json({
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        profile: user.profile,
      },
    });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Login a user
// loginUser POST {email: '', password: ''}
const loginUser = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res
        .status(400)
        .json({ error: 'No registered account by given email.' });
    }

    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }

    res.json({
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        profile: user.profile,
      },
    });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Get a user by ID
// getUser GET /:id
const getUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Update a user by ID
// updateUser: UPDATE /:id {}
const updateUser = async (req, res) => {
  try {
    const userId = req.params.id;
    const updatedUserData = req.body;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const updateObj = {};
    Object.keys(updatedUserData).forEach((key) => {
      if (key === 'profile') {
        updateObj[`profile`] = {
          ...user.profile,
          ...updatedUserData.profile,
        };
      } else {
        updateObj[key] = updatedUserData[key];
      }
    });

    // Perform the update using $set
    const updatedUser = await User.findByIdAndUpdate(
      userId,
      { $set: updateObj },
      { new: true }
    );

    res.json(updatedUser);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

module.exports = {
  loginUser,
  registerUser,
  getUser,
  updateUser,
};
