const { trendsModel: Trend } = require('../models/trends');
const { tweetModel: Tweet } = require('../models/tweet');

// Get top 5 trends
// getTopTrends: GET
const getTopTrends = async (req, res) => {
  try {
    const trends = await Trend.find().sort({ count: -1 }).limit(5);
    res.json(trends);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

// Get tweets by hashtag
// getTweetsByHashtag: GET /:hashtag
const getTweetsByHashtag = async (req, res) => {
  const { hashtag } = req.params;
  try {
    const tweets = await Tweet.find({ content: new RegExp(`#${hashtag}`, 'i') })
      .populate('author', 'username profile')
      .populate('retweetOf', 'content author')
      .limit(5);
    res.json(tweets);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

module.exports = {
  getTopTrends,
  getTweetsByHashtag,
};
